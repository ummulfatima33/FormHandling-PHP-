<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> CREATE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
  </head>
  <body>
   
   <div class="container">
    <div class="row">
        <div class="col-md-12 p-3">
            <h3>Fill This Form</h3>
                 <a href="index.php" class="btn btn-success m-3">Back</a>
            <form action="saveData.php" method="post" class="form-control p-4">

           <label for="form-label">Name</label>
           <input type="text" placeholder="enter your name" class="form-control" name="name">

           <label for="form-label">Email</label>
           <input type="email" placeholder="enter your email" class="form-control" name="email">

           <label for="form-label">City</label>
           <input type="text" placeholder="enter your city" class="form-control" name="city">

           <label for="form-label">Phone</label>
           <input type="number" placeholder="enter your number" class="form-control" name="phone">


           <input type="submit" class="btn btn-primary m-3" name="btnSave">
                    </form>
       
        </div>

    </div>
   </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
  </body>
</html>