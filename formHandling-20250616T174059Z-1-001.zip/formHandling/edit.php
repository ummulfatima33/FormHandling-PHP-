<?php
include "config.php";
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> CREATE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
  </head>

  <?php
    $user_id = $_GET['usrid'];

   $query = "SELECT * FROM tbl_user where id =$user_id";

   $result = mysqli_query($connection,$query);

   $usr = mysqli_fetch_assoc($result);

  //  print_r($result);
  //  exit();
?>


  <body>
   <div class="container">
    <div class="row">
        <div class="col-md-12 p-3">
            <h3>Edit This Form</h3>
                 <a href="index.php" class="btn btn-warning m-3">Back</a>
            <form action="update.php" method="post" class="form-control p-4">

            <input type="text" value="<?php echo $usr['id']; ?>" class="form-control" name="usrid">

           <label for="form-label">Name</label>
           <input type="text" value="<?php echo $usr['name']; ?>" class="form-control" name="usrname">

           <label for="form-label">Email</label>
           <input type="email"  value="<?php echo $usr['email']; ?>" class="form-control" name="usremail">

           <label for="form-label">City</label>
           <input type="text"  value="<?php echo $usr['city']; ?>" class="form-control" name="usrcity">

           <label for="form-label">Phone</label>
           <input type="number"  value="<?php echo $usr['phone']; ?>" class="form-control" name="usrphone">


           <input type="submit" class="btn btn-success m-3" name="btnUpdate" value="Update">
                    </form>
       
        </div>

    </div>
   </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
  </body>
</html>