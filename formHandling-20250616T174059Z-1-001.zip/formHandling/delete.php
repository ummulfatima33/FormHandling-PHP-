<?php
 include ('config.php');
 ?>
 <?php

$user_id = $_GET['usrid'];



 $query = "DELETE FROM tbl_user WHERE id =$user_id";
// $query = "DELETE FROM tbl_user";

  $result = mysqli_query($connection,$query);

  if($result) {
       header('Location: index.php');
   } else{
        echo "data not deleted!!!";
     }
    

 ?>
