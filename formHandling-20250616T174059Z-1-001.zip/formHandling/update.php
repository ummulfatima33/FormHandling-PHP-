<?php
include "config.php";

if(isset($_POST['btnUpdate'])) {

    $user_id = $_POST['usrid'];
    $user_name = $_POST['usrname'];
    $user_email = $_POST['usremail'];
    $user_city = $_POST['usrcity'];
    $user_phone = $_POST['usrphone'];

  $query = "UPDATE tbl_user SET name ='$user_name' , email = '$user_email', city = '$user_city',
   phone = '$user_phone' WHERE id= $user_id";
         $result = mysqli_query($connection,$query);
 
         if($result){
            header('Location:index.php');
         } else{
            echo 'Error for updating data';
         } 
            } else{
                echo 'Something went wrong!';
            }
?>

