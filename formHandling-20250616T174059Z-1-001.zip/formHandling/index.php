<?php
 include ("config.php");
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
  </head>
  <body>
   
   <div class="container">
    <div class="row">
        <div class="col-md-12 p-3">
        <h1>CRUD  OPERATION PHP</h1>
        <a href="create.php" class="btn btn-warning m-3">CREATE</a>

        <?php 
           $query = "SELECT * FROM tbl_user";
             $result = mysqli_query($connection,$query);

             if(mysqli_num_rows($result)) { ?>

       <table class="table table-hover">
        <thead>
          <tr>
          <th>S.no</th>
          <th>Name</th>
          <th>Email</th>
          <th>City</th>
          <th>Phone</th>
          <th>Action</th>
          </tr>
        </thead>
            <tbody>
              <?php
                   $count = 1;
              while ($row = mysqli_fetch_assoc($result)) { ?>
              <tr>
                <td><?php echo $count ?> </td>
                <td><?php echo $row['name']?></td>
                <td><?php echo $row['email']?></td>
                <td><?php echo $row['city']?></td>
                <td><?php echo $row['phone']?></td>
                <td>
                  <a href="view.php?usrid=<?php echo $row['id'] ?>" class="btn btn-primary">View</a>
                  <a href="edit.php?usrid=<?php echo $row['id'] ?>" class="btn btn-success">Edit</a> 
                  <a href="delete.php?usrid=<?php echo $row['id'] ?>" class="btn btn-danger">Delete</a> 
                  </td>
                 </tr>
                      <?php $count++; } ?> 
              </tbody>
                 </table>
            <?php }  else {
              echo "<p>No data found.</p>";
          } ?>
        </div>
    </div>
   </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
  </body>
</html>