<?php
  include('config.php');
   ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Data</title>
</head>

<?php

    $usr_id = $_GET['usrid'];

    $query = "SELECT * FROM tbl_user WHERE id = $usr_id";

        $result = mysqli_query($connection,$query);

        $usr = mysqli_fetch_assoc($result);
                  ?>
<body>

   <div class="container">
     <h1 class="mt-4"> View Data Here...</h1>

    <h2>Id :<?php echo $usr['id'] ?></h2>
    <h2>Name :<?php echo $usr['name'] ?></h2>
    <h3>Email :<?php echo $usr['email'] ?></h3>
    <h3>Contact :<?php echo $usr['phone'] ?></h3>
    <h3>City :<?php echo $usr['city'] ?></h3>
    </div>
</body>
</html>
