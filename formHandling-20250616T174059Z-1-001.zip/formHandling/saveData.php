<?php
 include "config.php";

 if(isset($_POST['btnSave'])){

 $name = $_POST['name'];
 $email = $_POST['email'];
 $city = $_POST['city'];
 $phone = $_POST['phone'];

    $query = "INSERT INTO tbl_user (name,email,city,phone) VALUES ('$name','$email','$city','$phone')";

      $result = mysqli_query($connection,$query);
      if($result){
            header('Location:index.php');
      }else{
            echo  'data not saved';
            }
      }
            
        else{
        echo 'Something went wrong!!!';
        }
        
        
        
     
        
        
