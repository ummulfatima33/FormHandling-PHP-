<?php

  $connection = mysqli_connect("localhost","root","","db_crud") or die("ERROR");


//   if($connection){
//      echo 'database connected';
//   } 
//      else {
//         echo 'database not connected';
//      }
?>